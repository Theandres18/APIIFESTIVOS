package com.andres.api_festivos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFestivosApplicationTests {

	@Test
	void contextLoads() {
	}

}
